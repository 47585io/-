package com.mycompany.who.Share;

abstract public class Idea
{
	public abstract boolean can(String s,String want,int start);
	
}
